from kartoteka.app import App

if __name__ == "__main__":
    App().mainloop()
