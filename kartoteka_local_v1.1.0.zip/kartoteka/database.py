\
import os
import sqlite3
import socket
import time
from datetime import datetime
from .config import load_config, photos_dir_for_db, thumbnails_dir_for_db

SCHEMA = r"""
PRAGMA foreign_keys = ON;
CREATE TABLE IF NOT EXISTS persons (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    surname TEXT,
    name TEXT,
    patronymic TEXT,
    full_name TEXT NOT NULL,
    alt_name TEXT,
    birth_date TEXT,
    birth_place TEXT,
    country TEXT DEFAULT 'Кыргызская Республика',
    short_bio TEXT,
    full_bio TEXT,
    note TEXT,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_persons_full_name ON persons(full_name);

CREATE TABLE IF NOT EXISTS departments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    official_name TEXT NOT NULL,
    short_name TEXT,
    department_type TEXT,
    start_year INTEGER,
    end_year INTEGER,
    previous_name TEXT,
    next_name TEXT,
    note TEXT,
    UNIQUE(official_name, start_year)
);
CREATE INDEX IF NOT EXISTS idx_departments_name ON departments(official_name);
CREATE INDEX IF NOT EXISTS idx_departments_short ON departments(short_name);

CREATE TABLE IF NOT EXISTS employment (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    person_id INTEGER NOT NULL,
    start_year INTEGER,
    end_year INTEGER,
    position TEXT,
    department_id INTEGER,
    department_text TEXT,
    organization TEXT,
    country TEXT DEFAULT 'Кыргызская Республика',
    note TEXT,
    FOREIGN KEY(person_id) REFERENCES persons(id) ON DELETE CASCADE,
    FOREIGN KEY(department_id) REFERENCES departments(id) ON DELETE SET NULL
);
CREATE INDEX IF NOT EXISTS idx_employment_person ON employment(person_id);
CREATE INDEX IF NOT EXISTS idx_employment_year ON employment(start_year,end_year);

CREATE TABLE IF NOT EXISTS photos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    person_id INTEGER NOT NULL,
    path TEXT NOT NULL,
    thumbnail_path TEXT,
    is_primary INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL,
    FOREIGN KEY(person_id) REFERENCES persons(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_photos_person ON photos(person_id);

CREATE TABLE IF NOT EXISTS sources (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    person_id INTEGER NOT NULL,
    title TEXT,
    url TEXT,
    note TEXT,
    FOREIGN KEY(person_id) REFERENCES persons(id) ON DELETE CASCADE
);
"""

DEPARTMENTS = [
("Администрация Президента Кыргызской Республики","АП КР","Высший государственный орган"),
("Кабинет Министров Кыргызской Республики","Кабмин КР","Правительство"),
("Аппарат Кабинета Министров Кыргызской Республики","Аппарат Кабмина","Аппарат правительства"),
("Жогорку Кенеш Кыргызской Республики","ЖК КР","Парламент"),
("Министерство иностранных дел Кыргызской Республики","МИД КР","Министерство"),
("Министерство внутренних дел Кыргызской Республики","МВД КР","Министерство"),
("Министерство обороны Кыргызской Республики","МО КР","Министерство"),
("Министерство юстиции Кыргызской Республики","Минюст КР","Министерство"),
("Министерство финансов Кыргызской Республики","Минфин КР","Министерство"),
("Министерство экономики и коммерции Кыргызской Республики","Минэкономики КР","Министерство"),
("Министерство здравоохранения Кыргызской Республики","Минздрав КР","Министерство"),
("Министерство просвещения Кыргызской Республики","Минпросвещения КР","Министерство"),
("Министерство науки, высшего образования и инноваций Кыргызской Республики","МНВОИ КР","Министерство"),
("Министерство труда, социального обеспечения и миграции Кыргызской Республики","Минтруд КР","Министерство"),
("Министерство чрезвычайных ситуаций Кыргызской Республики","МЧС КР","Министерство"),
("Министерство транспорта и коммуникаций Кыргызской Республики","Минтранс КР","Министерство"),
("Министерство энергетики Кыргызской Республики","Минэнерго КР","Министерство"),
("Министерство культуры, информации и молодежной политики Кыргызской Республики","Минкультуры КР","Министерство"),
("Государственный комитет национальной безопасности Кыргызской Республики","ГКНБ КР","Государственный комитет"),
("Генеральная прокуратура Кыргызской Республики","Генпрокуратура КР","Прокуратура"),
("Верховный суд Кыргызской Республики","ВС КР","Судебный орган"),
("Конституционный суд Кыргызской Республики","КС КР","Судебный орган"),
("Национальный банк Кыргызской Республики","НБ КР","Центральный банк"),
("Центральная комиссия по выборам и проведению референдумов Кыргызской Республики","ЦИК КР","Комиссия"),
("Счетная палата Кыргызской Республики","СП КР","Контрольный орган"),
("Национальный статистический комитет Кыргызской Республики","Нацстатком КР","Комитет"),
("Государственное агентство архивной службы при Кабинете Министров Кыргызской Республики","Госархив КР","Агентство"),
("Мэрия города Бишкек","Мэрия Бишкек","Орган местного самоуправления"),
("Мэрия города Ош","Мэрия Ош","Орган местного самоуправления"),
]

class DatabaseLockError(RuntimeError):
    pass

class DB:
    def __init__(self, path=None):
        self.path = os.path.abspath(path or load_config()["database_path"])
        self.conn = None
        self.lock_path = self.path + ".lock"
        self.lock_owned = False

    def is_network_path(self):
        p = self.path
        return p.startswith("\\\\") or (os.name == "nt" and len(p) >= 2 and p[1] == ":" and os.path.splitdrive(p)[0].upper() not in ("C:",))

    def acquire_network_lock(self):
        if not self.is_network_path():
            return
        os.makedirs(os.path.dirname(self.path), exist_ok=True)
        if os.path.exists(self.lock_path):
            try:
                age = time.time() - os.path.getmtime(self.lock_path)
            except Exception:
                age = 0
            if age < 12 * 3600:
                raise DatabaseLockError(
                    "Сетевая база уже открыта на другом компьютере.\n"
                    "Чтобы избежать повреждения SQLite, одновременная запись запрещена."
                )
            try:
                os.remove(self.lock_path)
            except Exception:
                raise DatabaseLockError("Не удалось снять старую блокировку сетевой базы.")
        with open(self.lock_path, "x", encoding="utf-8") as f:
            f.write("%s|%s|%s" % (socket.gethostname(), os.getpid(), datetime.now().isoformat()))
        self.lock_owned = True

    def release_lock(self):
        if self.lock_owned:
            try:
                if os.path.exists(self.lock_path):
                    os.remove(self.lock_path)
            except Exception:
                pass
            self.lock_owned = False

    def open(self):
        os.makedirs(os.path.dirname(self.path), exist_ok=True)
        self.acquire_network_lock()
        self.conn = sqlite3.connect(self.path, timeout=30)
        self.conn.row_factory = sqlite3.Row
        self.conn.execute("PRAGMA foreign_keys=ON")
        if not self.is_network_path():
            try:
                self.conn.execute("PRAGMA journal_mode=WAL")
            except Exception:
                pass
        self.conn.executescript(SCHEMA)
        self.seed_departments()
        self.conn.commit()
        for d in (photos_dir_for_db(self.path), thumbnails_dir_for_db(self.path)):
            os.makedirs(d, exist_ok=True)
        return self

    def close(self):
        try:
            if self.conn:
                self.conn.close()
        finally:
            self.conn = None
            self.release_lock()

    def seed_departments(self):
        for name, short, typ in DEPARTMENTS:
            self.conn.execute(
                "INSERT OR IGNORE INTO departments(official_name,short_name,department_type) VALUES(?,?,?)",
                (name, short, typ)
            )

    def now(self):
        return datetime.now().isoformat(timespec="seconds")
