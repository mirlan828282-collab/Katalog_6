\
from .database import DB

class Repository:
    def __init__(self, db):
        self.db = db

    @property
    def c(self):
        return self.db.conn

    def list_persons(self, q="", year=None, department="", organization=""):
        params=[]; where=[]
        sql="""SELECT DISTINCT p.* FROM persons p
        LEFT JOIN employment e ON e.person_id=p.id
        LEFT JOIN departments d ON d.id=e.department_id"""
        if q:
            qq="%"+q.strip()+"%"
            where.append("(p.full_name LIKE ? OR p.short_bio LIKE ? OR p.full_bio LIKE ? OR e.position LIKE ? OR e.organization LIKE ? OR d.official_name LIKE ? OR d.short_name LIKE ?)")
            params += [qq]*7
        if year:
            where.append("(e.start_year IS NULL OR e.start_year<=?) AND (e.end_year IS NULL OR e.end_year>=?)")
            params += [year,year]
        if department:
            qq="%"+department+"%"; where.append("(d.official_name LIKE ? OR d.short_name LIKE ? OR e.department_text LIKE ?)"); params += [qq,qq,qq]
        if organization:
            where.append("e.organization LIKE ?"); params.append("%"+organization+"%")
        if where: sql += " WHERE " + " AND ".join(where)
        sql += " ORDER BY p.full_name COLLATE NOCASE"
        return [dict(r) for r in self.c.execute(sql,params).fetchall()]

    def get_person(self,pid):
        p=self.c.execute("SELECT * FROM persons WHERE id=?",(pid,)).fetchone()
        if not p:return None
        x=dict(p)
        x["employment"]=[dict(r) for r in self.c.execute("""
            SELECT e.*, d.official_name AS department_name,d.short_name AS department_short
            FROM employment e LEFT JOIN departments d ON d.id=e.department_id
            WHERE e.person_id=? ORDER BY COALESCE(e.start_year,9999),id
        """,(pid,)).fetchall()]
        x["photos"]=[dict(r) for r in self.c.execute("SELECT * FROM photos WHERE person_id=? ORDER BY is_primary DESC,id",(pid,)).fetchall()]
        return x

    def duplicates(self,full_name):
        q="%"+full_name.strip()+"%"
        return [dict(r) for r in self.c.execute("SELECT * FROM persons WHERE full_name LIKE ? ORDER BY full_name LIMIT 20",(q,)).fetchall()]

    def create_person(self,full_name):
        full_name=(full_name or "").strip()
        if not full_name: raise ValueError("Введите ФИО.")
        ts=self.db.now()
        cur=self.c.execute("INSERT INTO persons(full_name,country,created_at,updated_at) VALUES(?,?,?,?)",
                           (full_name,"Кыргызская Республика",ts,ts))
        self.c.commit()
        return cur.lastrowid

    def update_person(self,pid,data):
        allowed=["surname","name","patronymic","full_name","alt_name","birth_date","birth_place","country","short_bio","full_bio","note"]
        sets=[]; vals=[]
        for k in allowed:
            if k in data:
                sets.append(k+"=?"); vals.append(data.get(k))
        sets.append("updated_at=?"); vals.append(self.db.now()); vals.append(pid)
        self.c.execute("UPDATE persons SET %s WHERE id=?"%",".join(sets),vals); self.c.commit()

    def delete_person(self,pid):
        self.c.execute("DELETE FROM persons WHERE id=?",(pid,)); self.c.commit()

    def departments(self,q=""):
        if q:
            qq="%"+q+"%"; rows=self.c.execute("SELECT * FROM departments WHERE official_name LIKE ? OR short_name LIKE ? ORDER BY official_name",(qq,qq)).fetchall()
        else:
            rows=self.c.execute("SELECT * FROM departments ORDER BY official_name").fetchall()
        return [dict(r) for r in rows]

    def add_department(self,name,short="",typ="",start_year=None,end_year=None,previous_name="",next_name="",note=""):
        cur=self.c.execute("""INSERT INTO departments(official_name,short_name,department_type,start_year,end_year,previous_name,next_name,note)
        VALUES(?,?,?,?,?,?,?,?)""",(name,short,typ,start_year,end_year,previous_name,next_name,note))
        self.c.commit(); return cur.lastrowid

    def update_department(self,did,data):
        keys=["official_name","short_name","department_type","start_year","end_year","previous_name","next_name","note"]
        sets=[]; vals=[]
        for k in keys:
            if k in data: sets.append(k+"=?"); vals.append(data[k])
        vals.append(did)
        self.c.execute("UPDATE departments SET %s WHERE id=?"%",".join(sets),vals); self.c.commit()

    def delete_department(self,did):
        self.c.execute("DELETE FROM departments WHERE id=?",(did,)); self.c.commit()

    def add_employment(self,pid,data):
        cur=self.c.execute("""INSERT INTO employment(person_id,start_year,end_year,position,department_id,department_text,organization,country,note)
        VALUES(?,?,?,?,?,?,?,?,?)""",(pid,data.get("start_year"),data.get("end_year"),data.get("position"),data.get("department_id"),
        data.get("department_text"),data.get("organization"),data.get("country") or "Кыргызская Республика",data.get("note")))
        self.c.commit(); return cur.lastrowid

    def delete_employment(self,eid):
        self.c.execute("DELETE FROM employment WHERE id=?",(eid,)); self.c.commit()

    def add_photo_record(self,pid,path,thumb,primary):
        if primary:self.c.execute("UPDATE photos SET is_primary=0 WHERE person_id=?",(pid,))
        cur=self.c.execute("INSERT INTO photos(person_id,path,thumbnail_path,is_primary,created_at) VALUES(?,?,?,?,?)",(pid,path,thumb,1 if primary else 0,self.db.now()))
        self.c.commit(); return cur.lastrowid
