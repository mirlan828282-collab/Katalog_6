\
import os, shutil, threading, webbrowser
import tkinter as tk
from tkinter import ttk, messagebox, filedialog, simpledialog
import ttkbootstrap as tb
from PIL import Image,ImageTk

from . import APP_NAME,APP_VERSION,CREATOR
from .config import load_config,save_config,DEFAULT_DB,BACKUP_DIR
from .database import DB,DatabaseLockError
from .repository import Repository
from .services import import_photo,import_excel,parse_bio

class App(tb.Window):
    def __init__(self):
        self.cfg=load_config()
        super().__init__(themename=self.cfg.get("theme","flatly"))
        self.title("%s — База данных персон"%APP_NAME)
        self.geometry("1500x900"); self.minsize(1180,720)
        self.db=None; self.repo=None; self.current_id=None; self.photo_img=None; self.save_after=None
        self._build_ui()
        self.protocol("WM_DELETE_WINDOW",self.on_close)
        self.after(100,self.open_configured_db)

    def _build_ui(self):
        top=ttk.Frame(self,padding=(14,10)); top.pack(fill="x")
        ttk.Label(top,text=APP_NAME,font=("Segoe UI",20,"bold")).pack(side="left")
        ttk.Label(top,text="База данных персон",font=("Segoe UI",11)).pack(side="left",padx=14)
        ttk.Label(top,text="Версия: %s   Создатель: %s"%(APP_VERSION,CREATOR),font=("Segoe UI",10)).pack(side="right")
        bar=ttk.Frame(self,padding=(14,0,14,8)); bar.pack(fill="x")
        actions=[
            ("＋ Добавить карточку",self.new_card,"primary.TButton"),
            ("Редактировать",self.focus_name,"secondary.TButton"),
            ("Массовый импорт",self.bulk_import,"secondary.TButton"),
            ("Поиск в интернете",self.search_web,"info.TButton"),
            ("CentrAsia",self.search_centrasia,"info.TButton"),
            ("Ведомства КР",self.departments_window,"success.TButton"),
            ("Настройки базы",self.database_settings,"warning.TButton"),
            ("Резервная копия",self.backup,"secondary.TButton"),
        ]
        for t,c,s in actions: ttk.Button(bar,text=t,command=c,style=s).pack(side="left",padx=(0,7))

        pane=ttk.Panedwindow(self,orient="horizontal"); pane.pack(fill="both",expand=True,padx=14,pady=(0,14))
        left=ttk.Frame(pane,padding=10); right=ttk.Frame(pane,padding=10); pane.add(left,weight=1); pane.add(right,weight=3)

        ttk.Label(left,text="Поиск",font=("Segoe UI",13,"bold")).pack(anchor="w")
        self.q=tk.StringVar(); qe=ttk.Entry(left,textvariable=self.q); qe.pack(fill="x",pady=(8,4)); qe.bind("<KeyRelease>",lambda e:self.reload_people())
        r=ttk.Frame(left); r.pack(fill="x")
        self.year=tk.StringVar(); ttk.Entry(r,textvariable=self.year,width=8).pack(side="left"); ttk.Button(r,text="По году",command=self.reload_people).pack(side="left",padx=5)
        self.dep_filter=tk.StringVar(); self.org_filter=tk.StringVar()
        ttk.Entry(left,textvariable=self.dep_filter).pack(fill="x",pady=3); ttk.Entry(left,textvariable=self.org_filter).pack(fill="x",pady=3)
        ttk.Button(left,text="Сбросить все",command=self.reset_filters).pack(fill="x",pady=(2,8))
        self.people=ttk.Treeview(left,columns=("fio",),show="headings"); self.people.heading("fio",text="ФИО"); self.people.column("fio",width=320)
        self.people.pack(fill="both",expand=True); self.people.bind("<<TreeviewSelect>>",self.on_select)

        self.status=ttk.Label(right,text="Готово"); self.status.pack(anchor="e")
        self.nb=ttk.Notebook(right); self.nb.pack(fill="both",expand=True)
        self.overview=ttk.Frame(self.nb,padding=12); self.details=ttk.Frame(self.nb,padding=12); self.photos=ttk.Frame(self.nb,padding=12)
        self.jobs=ttk.Frame(self.nb,padding=12); self.nb.add(self.overview,text="Главная"); self.nb.add(self.details,text="Сведения"); self.nb.add(self.photos,text="Фотографии"); self.nb.add(self.jobs,text="Должности")
        self._build_overview(); self._build_details(); self._build_photos(); self._build_jobs()

    def _build_overview(self):
        f=self.overview; f.columnconfigure(1,weight=1); f.rowconfigure(2,weight=1)
        self.main_photo=ttk.Label(f,text="Фото отсутствует",anchor="center")
        self.main_photo.grid(row=0,column=0,rowspan=3,sticky="nsew",padx=(0,20))
        self.ov_name=ttk.Label(f,text="Выберите человека",font=("Segoe UI",20,"bold")); self.ov_name.grid(row=0,column=1,sticky="nw")
        ttk.Label(f,text="Кем работал / должность / когда",font=("Segoe UI",13,"bold")).grid(row=1,column=1,sticky="w",pady=(16,6))
        self.ov_jobs=ttk.Treeview(f,columns=("when","position","where"),show="headings",height=16)
        for c,t,w in [("when","Когда",110),("position","Должность",300),("where","Ведомство / организация",420)]:
            self.ov_jobs.heading(c,text=t); self.ov_jobs.column(c,width=w,anchor="w")
        self.ov_jobs.grid(row=2,column=1,sticky="nsew")

    def _field(self,parent,label,row):
        ttk.Label(parent,text=label).grid(row=row,column=0,sticky="w",pady=5)
        v=tk.StringVar(); e=ttk.Entry(parent,textvariable=v); e.grid(row=row,column=1,sticky="ew",pady=5,padx=(8,0))
        e.bind("<KeyRelease>",self.schedule_save); e.bind("<FocusOut>",self.schedule_save)
        return v,e

    def _build_details(self):
        f=self.details; f.columnconfigure(1,weight=1); f.rowconfigure(9,weight=1)
        self.v_surname,_=self._field(f,"Фамилия",0); self.v_name,_=self._field(f,"Имя",1); self.v_patronymic,_=self._field(f,"Отчество",2)
        self.v_full,self.full_entry=self._field(f,"Полное ФИО",3); self.v_alt,_=self._field(f,"Альтернативное ФИО",4)
        self.v_birth,_=self._field(f,"Дата рождения",5); self.v_birth_place,_=self._field(f,"Место рождения",6); self.v_country,_=self._field(f,"Страна",7)
        ttk.Label(f,text="Полная биография").grid(row=8,column=0,sticky="nw",pady=5)
        self.bio=tk.Text(f,height=12,wrap="word",font=("Segoe UI",10)); self.bio.grid(row=8,column=1,sticky="nsew",pady=5); self.bio.bind("<KeyRelease>",self.schedule_save); self.bio.bind("<FocusOut>",self.schedule_save)
        ttk.Label(f,text="Примечание").grid(row=9,column=0,sticky="nw",pady=5)
        self.note=tk.Text(f,height=5,wrap="word",font=("Segoe UI",10)); self.note.grid(row=9,column=1,sticky="nsew",pady=5); self.note.bind("<KeyRelease>",self.schedule_save); self.note.bind("<FocusOut>",self.schedule_save)
        b=ttk.Frame(f); b.grid(row=10,column=1,sticky="e",pady=8)
        ttk.Button(b,text="Распознать периоды",command=self.parse_biography).pack(side="left",padx=4)
        ttk.Button(b,text="Удалить карточку",command=self.delete_person,style="danger.TButton").pack(side="left",padx=4)

    def _build_photos(self):
        bar=ttk.Frame(self.photos); bar.pack(fill="x")
        ttk.Button(bar,text="Добавить фото",command=self.add_photo).pack(side="left")
        self.photo_label=ttk.Label(self.photos,text="Фото отсутствует",anchor="center"); self.photo_label.pack(fill="both",expand=True,pady=10)

    def _build_jobs(self):
        b=ttk.Frame(self.jobs); b.pack(fill="x")
        ttk.Button(b,text="＋ Добавить период работы",command=self.add_job).pack(side="left")
        ttk.Button(b,text="Удалить выбранный",command=self.delete_job).pack(side="left",padx=6)
        self.jobtree=ttk.Treeview(self.jobs,columns=("s","e","p","d","o"),show="headings")
        for c,t,w in [("s","С",70),("e","По",70),("p","Должность",280),("d","Ведомство",320),("o","Организация",260)]:
            self.jobtree.heading(c,text=t); self.jobtree.column(c,width=w,anchor="w")
        self.jobtree.pack(fill="both",expand=True,pady=8)

    def open_configured_db(self):
        self.open_db(self.cfg.get("database_path") or DEFAULT_DB)

    def open_db(self,path):
        try:
            if self.db:self.db.close()
            self.db=DB(path).open(); self.repo=Repository(self.db)
            self.cfg["database_path"]=self.db.path; save_config(self.cfg)
            self.status.config(text="База: "+self.db.path)
            self.reload_people()
        except DatabaseLockError as e:
            messagebox.showerror("Сетевая база занята",str(e))
        except Exception as e:
            messagebox.showerror("Ошибка базы","Не удалось открыть базу данных.\n\n%s"%e)

    def database_settings(self):
        win=tk.Toplevel(self); win.title("Расположение базы данных"); win.geometry("760x260"); win.transient(self); win.grab_set()
        ttk.Label(win,text="Текущая база:",font=("Segoe UI",11,"bold")).pack(anchor="w",padx=16,pady=(16,5))
        pathv=tk.StringVar(value=self.db.path if self.db else self.cfg.get("database_path",DEFAULT_DB))
        ttk.Entry(win,textvariable=pathv,font=("Segoe UI",10)).pack(fill="x",padx=16)
        ttk.Label(win,text="Можно указать локальный путь или сетевой UNC-путь, например \\\\ARCHIVE-PC\\Kartoteka\\kartoteka.db").pack(anchor="w",padx=16,pady=8)
        row=ttk.Frame(win); row.pack(fill="x",padx=16,pady=8)
        def choose_existing():
            p=filedialog.askopenfilename(parent=win,filetypes=[("База SQLite","*.db"),("Все файлы","*.*")])
            if p:pathv.set(p)
        def choose_new():
            p=filedialog.asksaveasfilename(parent=win,defaultextension=".db",filetypes=[("База SQLite","*.db")],initialfile="kartoteka.db")
            if p:pathv.set(p)
        ttk.Button(row,text="Подключить существующую",command=choose_existing).pack(side="left")
        ttk.Button(row,text="Создать новую",command=choose_new).pack(side="left",padx=7)
        ttk.Button(row,text="Вернуть локальную",command=lambda:pathv.set(DEFAULT_DB)).pack(side="left")
        def apply():
            p=pathv.get().strip()
            if not p:return
            win.destroy(); self.open_db(p)
        ttk.Button(win,text="Применить",command=apply,style="primary.TButton").pack(pady=12)

    def reset_filters(self):
        self.q.set(""); self.year.set(""); self.dep_filter.set(""); self.org_filter.set(""); self.reload_people()

    def reload_people(self):
        if not self.repo:return
        y=self.year.get().strip()
        items=self.repo.list_persons(self.q.get(),int(y) if y.isdigit() else None,self.dep_filter.get(),self.org_filter.get())
        cur=self.current_id
        for i in self.people.get_children():self.people.delete(i)
        for p in items:self.people.insert("", "end", iid=str(p["id"]),values=(p.get("full_name") or "",))
        if cur and str(cur) in self.people.get_children(): self.people.selection_set(str(cur))

    def new_card(self):
        if not self.repo:
            messagebox.showerror("База","База данных не открыта."); return
        win=tk.Toplevel(self); win.title("Новая карточка"); win.geometry("540x180"); win.transient(self); win.grab_set()
        ttk.Label(win,text="Введите ФИО",font=("Segoe UI",12,"bold")).pack(anchor="w",padx=16,pady=(16,6))
        v=tk.StringVar(); e=ttk.Entry(win,textvariable=v,font=("Segoe UI",11)); e.pack(fill="x",padx=16); e.focus_set()
        info=ttk.Label(win,text="Пустая запись не создаётся."); info.pack(anchor="w",padx=16,pady=6)
        def create():
            fio=v.get().strip()
            if not fio:return
            try:
                dups=self.repo.duplicates(fio)
                if dups and not messagebox.askyesno("Возможный дубль","В базе найдена похожая персона.\nВсё равно создать новую?"):return
                pid=self.repo.create_person(fio)
                self.current_id=pid; win.destroy(); self.reload_people()
                if str(pid) in self.people.get_children(): self.people.selection_set(str(pid)); self.people.see(str(pid))
                self.load_person(pid); self.status.config(text="Сохранено")
            except Exception as ex:
                messagebox.showerror("Создание карточки","Карточка не создана.\n\n%s"%ex)
        ttk.Button(win,text="Создать карточку",command=create,style="primary.TButton").pack(pady=8)
        e.bind("<Return>",lambda _e:create())

    def on_select(self,_=None):
        s=self.people.selection()
        if s:self.load_person(int(s[0]))

    def load_person(self,pid):
        p=self.repo.get_person(pid)
        if not p:return
        self.current_id=pid; self.current=p
        for v,k in [(self.v_surname,"surname"),(self.v_name,"name"),(self.v_patronymic,"patronymic"),(self.v_full,"full_name"),(self.v_alt,"alt_name"),(self.v_birth,"birth_date"),(self.v_birth_place,"birth_place"),(self.v_country,"country")]:
            v.set(p.get(k) or "")
        self.bio.delete("1.0","end"); self.bio.insert("1.0",p.get("full_bio") or "")
        self.note.delete("1.0","end"); self.note.insert("1.0",p.get("note") or "")
        self.ov_name.config(text=p.get("full_name") or "")
        for tree in (self.ov_jobs,self.jobtree):
            for i in tree.get_children():tree.delete(i)
        for e in p.get("employment",[]):
            where=e.get("department_short") or e.get("department_name") or e.get("department_text") or ""
            if e.get("organization"): where=(where+" — " if where else "")+e["organization"]
            self.ov_jobs.insert("", "end",values=("%s–%s"%(e.get("start_year") or "",e.get("end_year") or "н.в."),e.get("position") or "",where))
            self.jobtree.insert("", "end",iid=str(e["id"]),values=(e.get("start_year") or "",e.get("end_year") or "",e.get("position") or "",e.get("department_short") or e.get("department_name") or e.get("department_text") or "",e.get("organization") or ""))
        photos=p.get("photos",[]); self.show_photo(photos[0]["thumbnail_path"] if photos else None)

    def show_photo(self,path):
        self.photo_img=None
        if path and os.path.exists(path):
            im=Image.open(path); im.thumbnail((430,600)); self.photo_img=ImageTk.PhotoImage(im)
            self.main_photo.config(image=self.photo_img,text=""); self.photo_label.config(image=self.photo_img,text="")
        else:
            self.main_photo.config(image="",text="Фото отсутствует"); self.photo_label.config(image="",text="Фото отсутствует")

    def schedule_save(self,_=None):
        if not self.current_id:return
        if self.save_after:self.after_cancel(self.save_after)
        self.status.config(text="Сохраняется...")
        self.save_after=self.after(700,self.save_current)

    def save_current(self):
        if not self.current_id:return
        try:
            self.repo.update_person(self.current_id,{
                "surname":self.v_surname.get(),"name":self.v_name.get(),"patronymic":self.v_patronymic.get(),"full_name":self.v_full.get(),
                "alt_name":self.v_alt.get(),"birth_date":self.v_birth.get(),"birth_place":self.v_birth_place.get(),"country":self.v_country.get(),
                "full_bio":self.bio.get("1.0","end").strip(),"note":self.note.get("1.0","end").strip()
            })
            self.status.config(text="Сохранено"); self.reload_people(); self.ov_name.config(text=self.v_full.get())
        except Exception as e: self.status.config(text="Ошибка сохранения"); messagebox.showerror("Сохранение",str(e))

    def focus_name(self): self.nb.select(self.details); self.full_entry.focus_set()

    def add_photo(self):
        if not self.current_id:return
        p=filedialog.askopenfilename(filetypes=[("Изображения","*.jpg *.jpeg *.png *.bmp")])
        if not p:return
        try:
            primary=not bool(self.current.get("photos"))
            import_photo(self.repo,self.current_id,p,primary); self.load_person(self.current_id)
        except Exception as e:messagebox.showerror("Фото",str(e))

    def add_job(self):
        if not self.current_id:return
        deps=self.repo.departments()
        win=tk.Toplevel(self); win.title("Добавить период работы"); win.geometry("760x430"); win.transient(self); win.grab_set()
        vars={}
        for i,(k,t) in enumerate([("start_year","С (год)"),("end_year","По (год)"),("position","Должность"),("organization","Организация"),("country","Страна"),("note","Примечание")]):
            ttk.Label(win,text=t).grid(row=i,column=0,sticky="w",padx=12,pady=7)
            v=tk.StringVar(value="Кыргызская Республика" if k=="country" else ""); vars[k]=v; ttk.Entry(win,textvariable=v).grid(row=i,column=1,sticky="ew",padx=12,pady=7)
        ttk.Label(win,text="Ведомство / Министерство").grid(row=6,column=0,sticky="w",padx=12,pady=7)
        dv=tk.StringVar(); combo=ttk.Combobox(win,textvariable=dv)
        mp={}
        vals=[]
        for d in deps:
            s=(d.get("short_name") or d["official_name"])+" — "+d["official_name"]; vals.append(s); mp[s]=d
        combo["values"]=vals; combo.grid(row=6,column=1,sticky="ew",padx=12,pady=7)
        def save():
            data={k:v.get().strip() for k,v in vars.items()}
            for k in ("start_year","end_year"): data[k]=int(data[k]) if data[k].isdigit() else None
            dep=mp.get(dv.get())
            if dep:data["department_id"]=dep["id"]
            else:data["department_text"]=dv.get().strip()
            self.repo.add_employment(self.current_id,data); win.destroy(); self.load_person(self.current_id)
        ttk.Button(win,text="Добавить",command=save,style="primary.TButton").grid(row=7,column=1,sticky="e",padx=12,pady=14)
        win.columnconfigure(1,weight=1)

    def delete_job(self):
        s=self.jobtree.selection()
        if s and messagebox.askyesno("Удаление","Удалить выбранный период работы?"):
            self.repo.delete_employment(int(s[0])); self.load_person(self.current_id)

    def delete_person(self):
        if self.current_id and messagebox.askyesno("Удаление","Удалить карточку?"):
            self.repo.delete_person(self.current_id); self.current_id=None; self.reload_people()

    def parse_biography(self):
        if not self.current_id:return
        items=parse_bio(self.bio.get("1.0","end"))
        if not items: messagebox.showinfo("Разбор","Периоды вида 1998–2001 не найдены."); return
        preview="\n".join("%s–%s — %s"%(x["start_year"],x["end_year"] or "н.в.",x["position"]) for x in items[:30])
        if messagebox.askyesno("Найдены периоды",preview+"\n\nДобавить в должности?"):
            for x in items:self.repo.add_employment(self.current_id,x)
            self.load_person(self.current_id)

    def departments_window(self):
        win=tk.Toplevel(self); win.title("Ведомства Кыргызской Республики"); win.geometry("1050x650")
        top=ttk.Frame(win); top.pack(fill="x",padx=12,pady=12)
        q=tk.StringVar(); ttk.Entry(top,textvariable=q).pack(side="left",fill="x",expand=True)
        tree=ttk.Treeview(win,columns=("short","name","type","years"),show="headings")
        for c,t,w in [("short","Сокращение",140),("name","Официальное название",500),("type","Тип",200),("years","Период",100)]:
            tree.heading(c,text=t); tree.column(c,width=w)
        tree.pack(fill="both",expand=True,padx=12)
        def reload(*_):
            for i in tree.get_children():tree.delete(i)
            for d in self.repo.departments(q.get()):
                yrs="%s–%s"%(d.get("start_year") or "",d.get("end_year") or "")
                tree.insert("", "end",iid=str(d["id"]),values=(d.get("short_name") or "",d["official_name"],d.get("department_type") or "",yrs))
        q.trace_add("write",reload)
        bar=ttk.Frame(win); bar.pack(fill="x",padx=12,pady=12)
        def add():
            name=simpledialog.askstring("Ведомство","Официальное название:",parent=win)
            if not name:return
            short=simpledialog.askstring("Ведомство","Сокращение:",parent=win) or ""
            typ=simpledialog.askstring("Ведомство","Тип:",parent=win) or ""
            self.repo.add_department(name,short,typ); reload()
        def edit():
            s=tree.selection()
            if not s:return
            did=int(s[0]); d=next((x for x in self.repo.departments() if x["id"]==did),None)
            if not d:return
            name=simpledialog.askstring("Редактировать","Официальное название:",initialvalue=d["official_name"],parent=win)
            if not name:return
            short=simpledialog.askstring("Редактировать","Сокращение:",initialvalue=d.get("short_name") or "",parent=win) or ""
            self.repo.update_department(did,{"official_name":name,"short_name":short}); reload()
        def delete():
            s=tree.selection()
            if s and messagebox.askyesno("Удаление","Удалить ведомство?",parent=win):
                self.repo.delete_department(int(s[0])); reload()
        ttk.Button(bar,text="＋ Добавить",command=add,style="success.TButton").pack(side="left")
        ttk.Button(bar,text="Редактировать",command=edit).pack(side="left",padx=6)
        ttk.Button(bar,text="Удалить",command=delete,style="danger.TButton").pack(side="left")
        reload()

    def bulk_import(self):
        p=filedialog.askopenfilename(filetypes=[("Excel","*.xlsx")])
        if not p:return
        try:
            c,s=import_excel(self.repo,p); self.reload_people(); messagebox.showinfo("Импорт","Добавлено: %s\nПропущено как дубли: %s"%(c,s))
        except Exception as e:messagebox.showerror("Импорт",str(e))

    def search_web(self):
        if self.current_id:
            fio=self.v_full.get().strip()
            if fio:webbrowser.open("https://www.google.com/search?q="+fio.replace(" ","+"))

    def search_centrasia(self):
        if self.current_id:
            fio=self.v_full.get().strip()
            if fio:webbrowser.open("https://centrasia.org/search.php?st="+fio.replace(" ","+"))

    def backup(self):
        if not self.db:return
        os.makedirs(BACKUP_DIR,exist_ok=True)
        from datetime import datetime
        dst=os.path.join(BACKUP_DIR,"kartoteka_%s.db"%datetime.now().strftime("%Y%m%d_%H%M%S"))
        try:
            b=self.db.conn.__class__(dst) if False else None
            import sqlite3
            out=sqlite3.connect(dst)
            with out:self.db.conn.backup(out)
            out.close()
            messagebox.showinfo("Резервная копия","Создано:\n"+dst)
        except Exception as e:messagebox.showerror("Резервная копия",str(e))

    def on_close(self):
        try:
            if self.db:self.db.close()
        finally:
            self.destroy()
