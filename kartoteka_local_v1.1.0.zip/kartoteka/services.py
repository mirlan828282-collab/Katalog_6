\
import os, shutil, uuid, re, webbrowser
from PIL import Image
from openpyxl import load_workbook
from .config import photos_dir_for_db, thumbnails_dir_for_db

def import_photo(repo,pid,src,primary=False):
    ext=os.path.splitext(src)[1].lower()
    if ext not in (".jpg",".jpeg",".png",".bmp"): raise ValueError("Поддерживаются JPG, JPEG, PNG, BMP.")
    stem="%s_%s"%(pid,uuid.uuid4().hex)
    pdir=photos_dir_for_db(repo.db.path); tdir=thumbnails_dir_for_db(repo.db.path)
    os.makedirs(pdir,exist_ok=True); os.makedirs(tdir,exist_ok=True)
    dst=os.path.join(pdir,stem+ext); thumb=os.path.join(tdir,stem+".jpg")
    shutil.copy2(src,dst)
    with Image.open(dst) as im:
        im=im.convert("RGB"); im.thumbnail((700,700)); im.save(thumb,"JPEG",quality=90)
    repo.add_photo_record(pid,dst,thumb,primary)
    return dst,thumb

def import_excel(repo,path):
    wb=load_workbook(path,read_only=True,data_only=True)
    ws=wb["Персоны"] if "Персоны" in wb.sheetnames else wb[wb.sheetnames[0]]
    rows=ws.iter_rows(values_only=True)
    headers=[str(x or "").strip() for x in next(rows)]
    idx={h:i for i,h in enumerate(headers)}
    fio_idx=idx.get("ФИО",idx.get("Полное ФИО"))
    if fio_idx is None: raise ValueError("В Excel нужна колонка «ФИО».")
    created=skipped=0
    for row in rows:
        if fio_idx>=len(row) or not row[fio_idx]: continue
        fio=str(row[fio_idx]).strip()
        if repo.duplicates(fio): skipped+=1; continue
        repo.create_person(fio); created+=1
    return created,skipped

PAT=re.compile(r"(?P<s>19\\d{2}|20\\d{2})\\s*[-–—]\\s*(?P<e>19\\d{2}|20\\d{2}|н\\.?\\s*в\\.?)\\s*[-–—:]?\\s*(?P<t>.+)",re.I)
def parse_bio(text):
    out=[]
    for line in (text or "").splitlines():
        m=PAT.match(line.strip(" •-"))
        if m:
            e=m.group("e")
            out.append({"start_year":int(m.group("s")),"end_year":int(e) if e.isdigit() else None,"position":m.group("t").strip()})
    return out
