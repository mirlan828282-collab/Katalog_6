\
import os
import json
import platform

APP_DIR = os.path.join(os.environ.get("PROGRAMDATA", r"C:\ProgramData"), "Kartoteka") if os.name == "nt" else os.path.abspath("./runtime_data")
DEFAULT_DB = os.path.join(APP_DIR, "data", "kartoteka.db")
CONFIG_FILE = os.path.join(APP_DIR, "config.json")
LOG_DIR = os.path.join(APP_DIR, "logs")
BACKUP_DIR = os.path.join(APP_DIR, "backups")

def ensure_app_dirs():
    for p in (APP_DIR, os.path.dirname(DEFAULT_DB), LOG_DIR, BACKUP_DIR):
        os.makedirs(p, exist_ok=True)

def load_config():
    ensure_app_dirs()
    cfg = {
        "database_path": DEFAULT_DB,
        "theme": "flatly",
        "photos_mode": "alongside_db"
    }
    if os.path.exists(CONFIG_FILE):
        try:
            with open(CONFIG_FILE, "r", encoding="utf-8") as f:
                cfg.update(json.load(f) or {})
        except Exception:
            pass
    return cfg

def save_config(cfg):
    ensure_app_dirs()
    with open(CONFIG_FILE, "w", encoding="utf-8") as f:
        json.dump(cfg, f, ensure_ascii=False, indent=2)

def photos_dir_for_db(db_path):
    folder = os.path.dirname(os.path.abspath(db_path))
    return os.path.join(folder, "photos")

def thumbnails_dir_for_db(db_path):
    folder = os.path.dirname(os.path.abspath(db_path))
    return os.path.join(folder, "thumbnails")
