APP_NAME = "КАРТОТЕКА"
APP_VERSION = "1.1.0"
CREATOR = "Esenbekov M."
