\
from kartoteka.services import parse_bio
def test_parse_bio():
    x=parse_bio("1998–2001 — начальник отдела")
    assert len(x)==1 and x[0]["start_year"]==1998 and x[0]["end_year"]==2001
