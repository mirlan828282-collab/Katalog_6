﻿\
﻿#define MyAppName "Картотека"
#define MyAppVersion "1.1.0"
#define MyAppPublisher "Esenbekov M."
#define MyAppExeName "Kartoteka.exe"

[Setup]
AppId={{A7F1F69B-92B2-48BC-A729-2310A2E42375}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
VersionInfoCompany={#MyAppPublisher}
VersionInfoDescription=КАРТОТЕКА — база данных персон
DefaultDirName={autopf}\Kartoteka
DefaultGroupName=Картотека
OutputDir=..\installer_output
OutputBaseFilename=Kartoteka_Setup_v1.1.0_Win7-11_x64
Compression=lzma2
SolidCompression=yes
ArchitecturesAllowed=x64
ArchitecturesInstallIn64BitMode=x64
PrivilegesRequired=admin
UninstallDisplayName=Картотека
WizardStyle=modern

[Files]
Source: "..\dist\Kartoteka.exe"; DestDir: "{app}"; Flags: ignoreversion

[Dirs]
Name: "{commonappdata}\Kartoteka\data"
Name: "{commonappdata}\Kartoteka\backups"
Name: "{commonappdata}\Kartoteka\logs"

[Icons]
Name: "{autoprograms}\Картотека"; Filename: "{app}\Kartoteka.exe"
Name: "{autodesktop}\Картотека"; Filename: "{app}\Kartoteka.exe"

[Run]
Filename: "{app}\Kartoteka.exe"; Description: "Запустить Картотеку"; Flags: nowait postinstall skipifsilent
