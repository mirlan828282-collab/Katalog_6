# КАРТОТЕКА 1.1.0 — локальная версия

Создатель: Esenbekov M.

Один исполняемый файл `Kartoteka.exe`.
Сервер не нужен.

## База данных
По умолчанию:
`C:\ProgramData\Kartoteka\data\kartoteka.db`

В настройках можно выбрать другую SQLite-базу, в том числе по UNC-пути:
`\\ARCHIVE-PC\Kartoteka\kartoteka.db`

Для сетевой SQLite-базы программа использует lock-файл и не допускает одновременную запись с нескольких ПК.

## Сборка
Windows 7 SP1 x64 / Windows 10 / Windows 11.
